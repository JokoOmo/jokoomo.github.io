(ns webnf.template
  (:require [webnf.base :refer [autoload-some]]
            [webnf.enlive :as we]
            [clojure.java.io :as io]))

(autoload-some
 ^:static (net.cgrand.enlive-html
           content set-attr select html-resource attr? do->)
 ^:static ^:macro (net.cgrand.enlive-html
                   clone-for)
 ^:static (webnf.enlive load-html))

(def content-dir "content")

(defn list-files [dir]
  (.listFiles (io/file "resources" content-dir dir)))

(defn cat-path [& path]
  (str (apply io/file path)))

(defmacro deftemplate [name path args & rules]
  `(we/deftemplate ~name ~(cat-path content-dir path) ~args ~@rules))

(defmacro defsnippet [name path selector args & rules]
  `(we/deftemplate ~name ~(cat-path content-dir path) ~selector ~args ~@rules))

(defn select-1 [html selector]
  (let [res (select html selector)]
    (when (> (count res) 1)
      (throw (ex-info (str "Selector " selector " returned more than one result")
                      {:selector selector})))
    (first res)))
