(ns static-templates.core
  (:require [clojure.java.io :as io]
            [clojure.pprint :refer [pprint]]
            [clojure.java.shell :refer [sh]]
            [webnf.template :refer [cat-path content-dir]]))

(comment (for [{f :sourcefile :as p} pages]
           {:target (.getName f)
            :content (page p)}))

(defn render-pages []
  (load-file "resources/content/template.clj")
  (let [ns (find-ns 'template)
        pages* (ns-resolve ns 'pages)
        copy* (ns-resolve ns 'copy-files)
        make-page* (ns-resolve ns 'page)
        out "resources/www"]
    (sh "rm" "-rf" out)
    (doseq [{sourcefile :sourcefile :as page} (pages*)
            :let [target-file (io/file out (.getName sourcefile))]]
      (-> target-file .getCanonicalFile .getParentFile .mkdirs)
      (with-open [w (io/writer target-file)]
        (doseq [s (make-page* page)]
          (.write w s))))
    (doseq [cf @copy*]
      (sh "cp" "-a" 
          (cat-path "resources" content-dir cf)
          (cat-path out cf)))))

(defn -main [& args]
  (println "Rendering into resources/www")
  (render-pages)
  (println "finished")
  (System/exit 0))
