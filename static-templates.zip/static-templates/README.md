# static-templates

This project aids in the creation of a home page by allowing
templating to generate directories of linked html files

## Usage

To output the site into the resources/www folder, open a terminal, cd
into the project directory and enter

    bin/lein run

This generates the www directory as described in resources/content/template.clj

Right now, it takes files from the pages directory, wraps them into
the main layout and generates tabs to each other page.
Styles derived from the wordpress theme snc-mono.

## License

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
