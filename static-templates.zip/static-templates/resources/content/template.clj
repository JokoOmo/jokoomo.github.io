(ns template
  [:require
   [clojure.pprint :refer [pprint]]
   [webnf.template :refer
    [deftemplate defsnippet content set-attr clone-for do->
     select select-1 html-resource
     attr?
     list-files cat-path]]])

(comment (defsnippet post "index.html" [:#main :.post]
           [{title :title date :date post-content :content href :href}]
           [:.post_title :a] (do-> (content title)
                                   (set-attr :href href))
           [:.post_date] (content date)
           [:.post_content] (content post-content)))

(def copy-files ["styles.css" "images"])

(deftemplate page "index.html"
  [{{title-text :text title-href :href} :title
    tabs :tabs
    page-content :content}]

  [:head :title] (content title-text)
  [:#header :a] (set-attr :href title-href)
  [:#header :.title] (content title-text)
  [:#content] (content page-content)
  [:#links :li] (clone-for [{:keys [href text]} tabs]
                           [:a] (do-> (set-attr :href href)
                                      (content text))))


(defn parse-page [page-html]
  (let [title (select-1 page-html [:head :title])
        body-content (select page-html [:body :> :*])]
    {:title {:text (:content title)
             :tab-name (get-in title [:attrs :data-tab-name])}
     :page-order (when-let [v (first (select page-html [(attr? :data-page-order)]))]
                   (Long/parseLong (get-in v [:attrs :data-page-order])))
     :content body-content}))

(defn pages [] 
  (let [pages (->> (list-files "pages")
                   (filter #(.endsWith (.getName %) ".html"))
                   (map (fn [f]
                          (-> f
                              html-resource parse-page
                              (assoc :sourcefile f))))
                   (sort-by :page-order))
        tabs (map #(hash-map :href (.getName (:sourcefile %))
                             :text (:tab-name (:title %)))
                  pages)]
    (pprint (map :title pages))
    (map #(assoc % :tabs tabs)
         pages)))
